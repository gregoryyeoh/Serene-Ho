<?php
/**
 * Theme footer for Serene Ho Profile.
 *
 * Provides the closing markup and ensures wp_footer() is called
 * so that Elementor and other plugins can enqueue scripts.
 */
?>

<?php wp_footer(); ?>
</body>
</html>


